export type VoterProps = {
    nickname: string;
    votes: number;
}