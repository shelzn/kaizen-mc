export const points = [
    { id: "e25eac754ee04a28dd52e8130230ae8127b089b0", amount: 10, image: "/pp_010.webp", color: "from-yellow-400", delay: "100" },
    { id: "e47dce73a9bf2b7262e2012484da16365b21208e", amount: 20, image: "/pp_020.webp", color: "from-yellow-500", delay: "200" },
    { id: "fe0d15c0d556689a42072c37c525b8db38211608", amount: 40, image: "/prp_040.webp", color: "from-green-400", delay: "300" },
    { id: "573c0aadebc30e6b479181bce24646e3487b7e9a", amount: 80, image: "/prp_080.webp", color: "from-green-500", delay: "400" },
    { id: "da3fded92872bcfc223c45e34184f50f422bd577", amount: 120, image: "/prp_120.webp", color: "from-blue-400", delay: "500" },
    { id: "8a19de8a99ba7f4e27b791198f7cb9a5bf5d7561", amount: 160, image: "/pp_160.webp", color: "from-blue-500", delay: "600" },
    { id: "8778350ac8346b1576eb248fb5b44b858f8a1c4a", amount: 240, image: "/prp_240.webp", color: "from-purple-400", delay: "700" },
    { id: "4d425b39c21425eef3b794440f4a8dce575eaf14", amount: 400, image: "/pp_400.webp", color: "from-purple-500", delay: "800" },
]